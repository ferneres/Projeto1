package br.ifpr.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.ifpr.modelo.Pessoa;
import br.ifpr.util.Conexao;

public class PessoaDAO {
   
	public void inserir (Pessoa p) throws SQLException {
		String sql="INSERT INTO pessoas(nome,email,telefone,altura,peso)"+
	   "VALUES (?,?,?,?,?)";
		
    Connection conn = Conexao.getConexao();
		
		PreparedStatement ps = conn.prepareStatement(sql);
		
		ps.setString(1,p.getNome());
		ps.setString(2,p.getEmail());
		ps.setString(3,p.getTelefone());
		ps.setFloat(4,p.getAltura());
		ps.setFloat(5,p.getPeso());
		
		ps.executeUpdate();
		
		conn.close();
	}
	
	public List <Pessoa> listar() throws SQLException {
		String sql = 
				"SELECT id_pessoa,nome,email,telefone,altura,peso"+
		" FROM pessoas";
	
	Connection conn = Conexao.getConexao();
	
	PreparedStatement ps = conn.prepareStatement(sql);
	
	ResultSet rs = ps.executeQuery();
	
	List <Pessoa> lista = new ArrayList<>();
	
	while(rs.next()) {
		Pessoa p = new Pessoa();
		p.setId(rs.getInt("id_pessoa"));
		p.setNome(rs.getString("nome"));
		p.setEmail(rs.getString("email"));
		p.setTelefone(rs.getString("telefone"));
		p.setAltura(rs.getFloat("altura"));
		p.setPeso(rs.getFloat("peso"));
		
		lista.add(p);
	}
	
	conn.close();
	
	return lista;

	}
	
	public Pessoa buscar(Integer id) throws SQLException {
		Pessoa p = null;
		
		String sql = 
				"SELECT  id_pessoa,nome,email,telefone,altura,peso" +
				" FROM pessoas WHERE  id_pessoa = ?";
		
		Connection conn = Conexao.getConexao();
		
		PreparedStatement ps = 
				conn.prepareStatement(sql);
		ps.setInt(1, id);
		
		ResultSet rs = ps.executeQuery();
		
		if(rs.next()) {
	
		 p = new Pessoa();
			p.setId(rs.getInt("id_pessoa"));
			p.setNome(rs.getString("nome"));
			p.setEmail(rs.getString("email"));
			p.setTelefone(rs.getString("telefone"));
			p.setAltura(rs.getFloat("altura"));
			p.setPeso(rs.getFloat("peso"));
			
		} 
		
		conn.close();
		
		return p; 
	}
	

	public void excluir(Integer id) throws SQLException {
		String sql = "DELETE FROM pessoas WHERE  id_pessoa = ?";
		
		Connection conn = Conexao.getConexao();
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		
		ps.executeUpdate();
		
		conn.close();
	}

}
