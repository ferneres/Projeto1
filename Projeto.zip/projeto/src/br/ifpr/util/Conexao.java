package br.ifpr.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

	public static Connection getConexao() {
		Connection conn = null;
		
		try {
			conn = DriverManager.getConnection(
			"jdbc:mysql://localhost:3306/projeto","root","bancodedados");
			
		} catch (SQLException e) {
			System.out.println("\n| Erro ao conectar a base de dados.");
			e.printStackTrace();
		}
		
		return conn;
	}
	
}
