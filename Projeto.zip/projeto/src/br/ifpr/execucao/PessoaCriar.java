package br.ifpr.execucao;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import br.ifpr.DAO.PessoaDAO;
import br.ifpr.modelo.Pessoa;

public class PessoaCriar {

	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		 
		Pessoa p = new Pessoa();
		
		
		System.out.println("Informe o Nome: ");
		String nome = reader.readLine();
		p.setNome(nome);
		
		System.out.println("Informe o e-mail: ");
		String email = reader.readLine();
		p.setEmail(email);
		
		System.out.println("Informe o Telefone: ");
		String telefone = reader.readLine();
		p.setTelefone(telefone);
		
		System.out.println("Informe a Altura: ");
		String altura = reader.readLine();
		p.setAltura(Float.parseFloat(altura));
		
		System.out.println("Informe o Peso: ");
		String peso = reader.readLine();
		p.setPeso(Float.parseFloat(peso));
		
		System.out.println(p.retornaDadosPessoa());
		
		PessoaDAO pDao= new PessoaDAO();
		pDao.inserir(p);
	}
}
