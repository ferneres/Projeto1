package br.ifpr.execucao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import br.ifpr.DAO.PessoaDAO;
import br.ifpr.modelo.Pessoa;

public class PessoaExcluir {

	public static void main(String[] args) throws IOException, NumberFormatException, SQLException {
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		
			System.out.println("|Informe a pessoa a ser excluída: ");
			
			String id = reader.readLine();
			Integer idInt = Integer.parseInt(id);			
		
			PessoaDAO pDao = new PessoaDAO();
			Pessoa p  = pDao.buscar(Integer.parseInt(id));
			pDao.buscar(Integer.parseInt(id));
			
			if(p != null) {
				
				pDao.excluir(idInt);
				System.out.println("| A pessoa com  ID " + id + ", foi excluida com sucesso.");
			} else {
				System.out.println("| A pessoa com o ID " + id
						+ ", não encontrada na lista");
			}
	}

	}


