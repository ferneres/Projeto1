package br.ifpr.execucao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import br.ifpr.DAO.PessoaDAO;
import br.ifpr.modelo.Pessoa;

public class PessoaBuscar {

	public static void main(String[] args) throws IOException, NumberFormatException, SQLException {
	
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		
			System.out.println("|Insira o Id da pessoa que deseja: ");
			
			String idprod = reader.readLine();

			
			PessoaDAO pDAO = new PessoaDAO();
			
			Pessoa p = pDAO.buscar(Integer.parseInt(idprod));

			if(p == null) {
				System.out.println("|Pessoa não encontrada na lista");
			}
			else {
				System.out.println(p);
			}

			
		}

	}

