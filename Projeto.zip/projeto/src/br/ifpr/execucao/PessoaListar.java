package br.ifpr.execucao;

import java.sql.SQLException;
import java.util.List;

import br.ifpr.DAO.PessoaDAO;
import br.ifpr.modelo.Pessoa;

public class PessoaListar {

	public static void main(String[] args) throws SQLException {
	
		PessoaDAO pDAO = new PessoaDAO();
		List <Pessoa> lista = pDAO.listar();

		System.out.println(lista.size());
		for (Pessoa pessoa : lista) {
			System.out.println(pessoa);
			
		}
	}

	}


