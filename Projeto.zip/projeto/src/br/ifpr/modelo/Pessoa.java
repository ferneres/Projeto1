package br.ifpr.modelo;

public class Pessoa {

	private Integer id;
	private String nome;
	private String email;
	private String telefone;
	private Float altura;
	private Float peso;
	
	public String retornaDadosPessoa() {
		String 
		p = "\n| ID = " + id;
		p = "\n| Nome = " +nome ;
		p += "\n| Email = "+ email;
		p += "\n| Telefone = "+ telefone;
		p += "\n| Altura = "+ altura;
		p+= "\n| Peso = "+ peso;
		
		
		return p;
	}
	public String toString() {
		return this.retornaDadosPessoa();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Float getAltura() {
		return altura;
	}
	public void setAltura(Float altura) {
		this.altura = altura;
	}
	public Float getPeso() {
		return peso;
	}
	public void setPeso(Float peso) {
		this.peso = peso;
	}
	
	
}
